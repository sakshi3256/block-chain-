import React, { Component } from 'react';

export const About = () =>(
    <div>
        <h1>About Us</h1>
    </div>
)
