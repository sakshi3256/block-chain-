import React, { Component } from 'react';



export const Contact = () =>(
    <div>
        <h1>Contact us</h1>
    </div>
)
