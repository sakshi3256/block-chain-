import React, { Component } from 'react';

export const NoMatch = () =>(
    <div>
        <h1> NoMatch </h1>
    </div>
)
