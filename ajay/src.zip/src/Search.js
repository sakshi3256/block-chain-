import React, { Component } from 'react';

export const Search = () =>(
    <div>
        <h1> Search </h1>
    </div>
)
